#!/usr/bin/env python
# encoding: utf-8
"""
SCUtilities: tools for dealing with Apple's SystemConfiguration framework

Created by Chris Adams on 2008-05-28.
"""

# TODO: Import code related to SystemConfiguration events

import sys
import os
import unittest

class SCUtilitiesTests(unittest.TestCase):
  def setUp(self):
    raise RuntimeError("Thwack Chris about not writing these yet")

if __name__ == '__main__':
  unittest.main()
